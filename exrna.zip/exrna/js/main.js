/* exRNA Therapeutics - site behaviour (vanilla JS) */
(function () {
  "use strict";

  // --- Header state on scroll ------------------------------------------
  var header = document.querySelector("[data-site-header]");
  if (header) {
    var ticking = false;
    var updateHeader = function () {
      header.dataset.scrolled = window.scrollY > 8 ? "true" : "false";
      ticking = false;
    };
    window.addEventListener(
      "scroll",
      function () {
        if (!ticking) {
          ticking = true;
          window.requestAnimationFrame(updateHeader);
        }
      },
      { passive: true },
    );
    updateHeader();
  }

  // --- Mobile navigation -----------------------------------------------
  var toggle = document.querySelector("[data-nav-toggle]");
  var nav = document.querySelector("[data-site-nav]");
  if (toggle && nav) {
    var setOpen = function (open) {
      toggle.setAttribute("aria-expanded", String(open));
      nav.dataset.open = String(open);
    };
    setOpen(false);

    toggle.addEventListener("click", function () {
      setOpen(toggle.getAttribute("aria-expanded") !== "true");
    });
    nav.addEventListener("click", function (event) {
      if (event.target.closest("a")) setOpen(false);
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && toggle.getAttribute("aria-expanded") === "true") {
        setOpen(false);
        toggle.focus();
      }
    });
    var wide = window.matchMedia("(min-width: 48em)");
    wide.addEventListener("change", function (event) {
      if (event.matches) setOpen(false);
    });
  }

  // --- Section reveal ----------------------------------------------------
  // Content is visible by default; only elements that start below the fold
  // are animated, and the animation never leaves text faded.
  var prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var canAnimate =
    !prefersReducedMotion &&
    "IntersectionObserver" in window &&
    typeof Element.prototype.animate === "function";

  if (canAnimate) {
    var pending = new Set();
    document.querySelectorAll(".reveal").forEach(function (el) {
      if (el.getBoundingClientRect().top > window.innerHeight) pending.add(el);
    });

    if (pending.size > 0) {
      var play = function (el) {
        var delay = Number(el.dataset.revealDelay || 0) * 70;
        el.animate(
          [
            { opacity: 0, transform: "translateY(12px)" },
            { opacity: 1, transform: "none" },
          ],
          { duration: 460, delay: delay, easing: "cubic-bezier(0.2, 0, 0.2, 1)", fill: "none" },
        );
      };
      var observer = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            var el = entry.target;
            observer.unobserve(el);
            if (pending.delete(el)) play(el);
          });
        },
        { rootMargin: "0px 0px 80px 0px", threshold: 0 },
      );
      pending.forEach(function (el) {
        observer.observe(el);
      });
    }
  }
})();
