# exRNA Therapeutics - static website

Plain HTML, CSS and JavaScript. No build step, no framework.

- Open `index.html` in a browser, or upload the whole folder to any static host.
- `css/style.css` - all styles
- `js/main.js` - sticky header, mobile menu, scroll reveal
- `fonts/`, `brand/` - self-hosted fonts and logos
